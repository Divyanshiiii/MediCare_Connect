package com.example.medics

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
